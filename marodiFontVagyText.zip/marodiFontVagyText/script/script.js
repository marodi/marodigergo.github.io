function $(id){
    return document.getElementById(id);
}

function change(){
    $('example').style.fontSize = document.forms['urlap']['size'].value;
    $('example').style.fontStyle = document.forms['urlap']['style'].value;
    $('example').style.fontFamily = document.forms['urlap']['family'].value;
    $('example').style.textAlign = document.forms['urlapketto']['align'].value;
    $('example').style.textTransform = document.forms['urlapketto']['transform'].value;
    $('example').style.textIndent = document.forms['urlapketto']['indent'].value;
}

function init(){
    change();
    //$('font').addEventListener('click', change(), false);
    //$('text').addEventListener('click', change(), false);
}

window.addEventListener('load', init(), false);